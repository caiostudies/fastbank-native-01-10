import { Text, View, TouchableOpacity } from 'react-native';
import { AntDesign } from "@expo/vector-icons";
import style from './App.module.css';


export default function index({navigation}) {
  function Pix(){
    navigation.navigate('Pix')
  }

  function cartoes(){
    navigation.navigate('Cartoes')
  }

  function cartao1(){
    navigation.navigate('Cartao1')
  }
  return (
    <View style={style.container}>
      <View style={style.bg}></View>
      <View style={style.containerElipse}>
        <TouchableOpacity style={style.elipse}>
          <AntDesign
            name="picture"
            size={30}
            color={'#1d9fdb'}
            onPress={Pix}
          />
        </TouchableOpacity>
        <TouchableOpacity style={style.elipse}>
          <AntDesign
            name="picture"
            size={30}
            color={'#1d9fdb'}
            onPress={cartoes}
          />
        </TouchableOpacity>
        <TouchableOpacity style={style.elipse}>
          <AntDesign
            name="picture"
            size={30}
            color={'#1d9fdb'}
            onPress={cartao1}
          />
        </TouchableOpacity>
        <TouchableOpacity style={style.elipse}>
          <AntDesign
            name="picture"
            size={30}
            color={'#1d9fdb'}
          />
        </TouchableOpacity>
      </View>
      <View style={style.bg2}></View>
      <View style={style.bg3}></View>
    </View>
  );
}
