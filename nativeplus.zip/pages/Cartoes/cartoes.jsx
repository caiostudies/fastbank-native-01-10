import { Text, View, TouchableOpacity } from 'react-native';
import { AntDesign } from "@expo/vector-icons";
import { Ionicons } from '@expo/vector-icons'; 
import style from './cartoes.module.css';

export default function index({navigation}) {
    function Home(){
        navigation.navigate('Home')
      }

    return (
        <View style={style.container}>
            <View style={style.bg}>

                <TouchableOpacity style={style.sair}>
                    <AntDesign
                        name="export"
                        size={30}
                        color={'#fff'}
                        onPress={Home}
                    />
                </TouchableOpacity>

                <TouchableOpacity style={style.elipse}>
                    <Ionicons
                        name="card"
                        size={30}
                        color={'#fff'}
                    />
                </TouchableOpacity>

                <Text style={style.titulo}>Cartões</Text>

                <Text style={style.sub}>Cartões físicos</Text>

                <Text style={style.linha}></Text>


                



            </View>
       

        </View>
      
    )
}