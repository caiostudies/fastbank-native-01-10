import { Text, View, TouchableOpacity } from 'react-native';
import style from './Style.module.css';


export default function index() {
  return (
    <View style={style.container}>
      <View style={style.bg}></View>

    </View>
  );
}
