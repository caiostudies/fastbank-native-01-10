import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import Home from "./pages/Home/index.jsx";
import Pix from "./pages/Pix/index.jsx";
import Cartoes from "./pages/Cartoes/cartoes.jsx"
import Cartao1 from "./pages/Cartao1/debito.jsx"


const Pilha = createStackNavigator()

export default function Routers({navigation}) {
    return (
        <NavigationContainer>
            <Pilha.Navigator>
                <Pilha.Screen
                    name="Home"
                    component={Home}
                    options={{ headerShown: false }}
                />

                <Pilha.Screen
                    name="Pix"
                    component={Pix}
                    options={{ headerShown: false }}
                />

                <Pilha.Screen
                    name="Cartoes"
                    component={Cartoes}
                    options={{ headerShown: false }}
                />

                 <Pilha.Screen
                    name="Cartao1"
                    component={Cartao1}
                    options={{ headerShown: false }}
                />
            </Pilha.Navigator>
        </NavigationContainer>
    )
}